﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Student.Controllers
{
    public class StudentController : Controller
    {
        public static List<course> coursesList = new List<course>() { new course() { Id = 1, Name = "Course 1" }, new course() { Name = "Course 2", Id = 2 }, new course() { Name = "Course 3", Id = 3 } };

        public static List<student> studentList = new List<student>() {
            new student() { Id = 1, Name = "Person One", Grade = "Year 1", GPA = 5.60f, courses = coursesList.Where(n => n.Id == 2).ToList()  },
            new student() { Id = 2, Name = "Person Two", Grade = "Year 2", GPA = 8.50f, courses = coursesList.Where(n => n.Id == 1).ToList() },
            new student() { Id = 3, Name = "Person Three", Grade = "Year 3", GPA = 7.42f, courses = coursesList.Where(n => n.Id == 3).ToList()}
        };

        public ActionResult Index(string Name = null)
        {
            if (Name == null)
            {
                return View(studentList);
            }
            else
            {
                return View(studentList.Where(n => n.Name.ToLower().Contains(Name.Trim().ToLower())));
            }
        }
        public ActionResult getCourses()
        {
            return Json(coursesList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult getStudent(int id)
        {
            return Json(studentList.Where(x => x.Id == id).FirstOrDefault(), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public void addCourse(student student)
        {
            studentList.Where(x => x.Id == student.Id).First().courses = student.courses.OrderBy(x => x.Id).ToList();
        }
    }



    public class student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Grade { get; set; }
        public float GPA { get; set; }
        public List<course> courses { get; set; }
        public student()
        {
            courses = new List<course>();
        }

    }

    public class course
    {
        public string Name { get; set; }
        public int Id { get; set; }

        public static implicit operator List<object>(course v)
        {
            throw new NotImplementedException();
        }
    }
}